﻿using System;
using System.Collections.Generic;

namespace KebunBinatangApp
{
    public class Hewan
    {
        public string nama;
        public int umur;

        public virtual string Suara()
        {
            return "Hewan ini mengeluarkan suara";
        }

        public virtual string InfoHewan()
        {
            return $"Nama: {nama}, Umur: {umur} tahun";
        }
    }

  
    public class Mamalia : Hewan
    {
        
    }

    
    public class Reptil : Hewan
    {
       
    }

 
    public class Singa : Mamalia
    {
        public override string Suara()
        {
            return "Singa mengaum!";
        }

        public void Mengaum()
        {
            Console.WriteLine("Singa sedang mengaum!");
        }
    }

   
    public class Gajah : Mamalia
    {
        public override string Suara()
        {
            return "Gajah mengeluarkan suara terompet!";
        }
    }

    public class Ular : Reptil
    {
        public override string Suara()
        {
            return "Ular mendesis!";
        }

        public void Merayap()
        {
            Console.WriteLine("Ular sedang merayap!");
        }
    }

    
    public class Buaya : Reptil
    {
        public override string Suara()
        {
            return "Buaya menggeram!";
        }
    }

   
    public class KebunBinatang
    {
        private List<Hewan> daftarHewan = new List<Hewan>();

        public void TambahHewan(Hewan hewan)
        {
            daftarHewan.Add(hewan);
        }

        public void TampilkanDaftarHewan()
        {
            foreach (var hewan in daftarHewan)
            {
                Console.WriteLine(hewan.InfoHewan());
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            
            KebunBinatang kebunBinatang = new KebunBinatang();

            
            Singa singa = new Singa { nama = "Singa Leo", umur = 5 };
            Gajah gajah = new Gajah { nama = "Gajah Jumbo", umur = 10 };
            Ular ular = new Ular { nama = "Ular Slyther", umur = 3 };
            Buaya buaya = new Buaya { nama = "Buaya Garang", umur = 7 };

           
            kebunBinatang.TambahHewan(singa);
            kebunBinatang.TambahHewan(gajah);
            kebunBinatang.TambahHewan(ular);
            kebunBinatang.TambahHewan(buaya);

            
            kebunBinatang.TampilkanDaftarHewan();

            
            Console.WriteLine(singa.Suara());
            Console.WriteLine(gajah.Suara());
            Console.WriteLine(ular.Suara());

            singa.Mengaum();
            ular.Merayap();
        }
    }
}
